const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public')); // index.html burada

app.post('/kaydet-ip', (req, res) => {
  const ip = req.body.ip;
  const klasorYolu = path.join(__dirname, 'ip');
  const dosyaYolu = path.join(klasorYolu, 'ip.txt');

  // Eğer klasör yoksa oluştur
  if (!fs.existsSync(klasorYolu)) {
    fs.mkdirSync(klasorYolu);
  }

  // IP adresini dosyaya yaz
  fs.writeFileSync(dosyaYolu, ip + '\n');
  res.json({ mesaj: 'IP başarıyla kaydedildi' });
});

app.listen(PORT, () => {
  console.log(`Sunucu çalışıyor: http://localhost:${PORT}`);
});
